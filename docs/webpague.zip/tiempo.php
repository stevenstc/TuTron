<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>YOUTRON777-REGRESIVE</title>
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,600,700,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos.css">
    <link rel="icon" href="images/favicon.png">

</head>
<body class="uno">

    <div class="portada" id="portada" style="background:rgba(34, 34, 34, 0.8);" >
        <div class="header">
            <h1 class="logotipo">YOUTRON777</h1>'
            ;?>
            <div style="margin-left: 5rem;  margin-right: 5rem;"><p class="mensaje">PROJECT UNDER CONSTRUCTION</p></div>

            <?php
                echo'
        </div>

        <div id="cuenta"></div>
<h1>Official release on April 21, 7pm</h1>
<div class="redes-sociales">

        <p>Acces of system administrator!</p><br>
            <!--<a href="" class="btn-red-social"><i class="fab fa-facebook-f"></i></a>
            <a href="" class="btn-red-social"><i class="fab fa-twitter"></i></a>-->
            <form method="post" role="form" class="php-email-form">
              <div class="subscribe-form">
                <input type="text" name="token" style="padding: 10px;border-radius: 5px;background: azure; color:#000;" class="btn-red-social" placeholder="ingresa su token de  acceso"><br><br><input type="submit" value="ACCEDER" style="padding: 10px;" class="btn-red-social">
              </div>
              <div class="mt-2">
                <div class="error-message" style="color:red">'.@$error.'</div>
              </div>
            </form>
        </div>
    </div>

    <main class="contenedor">

    </main>

    <script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
    <script src="js/simplyCountdown.min.js"></script>
    <script src="js/countdown.js"></script>
</body>
</html>';

?>
